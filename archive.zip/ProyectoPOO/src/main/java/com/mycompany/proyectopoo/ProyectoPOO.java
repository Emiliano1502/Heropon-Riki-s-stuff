
package com.mycompany.proyectopoo;
import GUI.Login;
import org.json.JSONObject;
import org.json.JSONArray;

/**
 * @team Plaga
 * @author Gil de Gaona Jazmín
 * @author Hernández Peña Angel Adrian
 * @author Moreno Vigueras Arturo Tadeo
 * @author Ruiz Emiliano
 * @version 1.0
 */


public class ProyectoPOO {

    public static void main(String[] args) {
        Login panta = new Login();
        panta.setVisible(true);
        panta.setLocationRelativeTo(null);
    }
}
